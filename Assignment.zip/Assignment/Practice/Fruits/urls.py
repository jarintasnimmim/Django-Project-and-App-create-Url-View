from django.urls import path
from . import views


urlpatterns = [
    
     path('', views.Summer_Fruits),
     path('Monsoon Fruits/', views.Monsoon_Fruits),
     path('Autumn Fruits/', views.Autumn_Fruits),
     path('Winter Fruits/', views.Winter_Fruits),
     path('Year Round Fruits/', views.Year_Round_Fruits),
]