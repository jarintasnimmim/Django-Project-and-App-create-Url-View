from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def Summer_Fruits(request):
    return render(request,'summer-fruits.html')

def Monsoon_Fruits(request):
    return render(request,'monsoon-fruits.html')

def Autumn_Fruits(request):
    return render(request,'autumn-fruits.html')

def Winter_Fruits(request):
    return render(request,'winter-fruits.html')

def Year_Round_Fruits(request):
    return render(request,'spring-fruits.html')