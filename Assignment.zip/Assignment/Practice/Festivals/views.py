from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def Summer_Festivals(request):
    return render(request,'summer-festivals.html')

def Rainy_Season_Festivals(request):
    return render(request,'rainy-festivals.html')

def Autumn_Festivals(request):
    return render(request,'autumn-festivals.html')

def Winter_Festivals(request):
    return render(request,'winter-festivals.html')

def Spring_Festivals(request):
    return render(request,'spring-festivals.html') 
