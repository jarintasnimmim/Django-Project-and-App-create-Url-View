from django.urls import path
from . import views


urlpatterns = [
    
     path('Summer Festivals/', views.Summer_Festivals),
     path('Rainy Season Festivals/', views.Rainy_Season_Festivals),
     path('Autumn Festivals/', views.Autumn_Festivals),
     path('Winter Festivals/', views.Winter_Festivals),
     path('Spring Festivals/', views. Spring_Festivals),
]