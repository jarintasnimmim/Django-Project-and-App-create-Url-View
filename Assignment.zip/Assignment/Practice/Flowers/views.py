from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def Summer_Flowers(request):
    return render(request,'summer-flowers.html')

def Rainy_Season_Flowers(request):
    return render(request,'rainy-flowers.html')

def Spring_Flowers(request):
    return render(request,'spring-flowers.html')

def Winter_Flowers(request):
    return render(request,'winter-flowers.html')

def Autumn_Flowers(request):
    return render(request,'autumn-flowers.html')
