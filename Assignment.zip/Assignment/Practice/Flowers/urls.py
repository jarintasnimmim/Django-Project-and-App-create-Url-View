from django.urls import path
from . import views


urlpatterns = [
    
     path('Summer Flowers/', views.Summer_Flowers),
     path('Rainy Season Flowers/', views.Rainy_Season_Flowers),
     path('Spring Flowers/', views.Spring_Flowers),
     path('Winter Flowers/', views.Winter_Flowers),
     path('Autumn Flowers/', views.Autumn_Flowers),
]